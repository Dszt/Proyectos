package com.example.Proyecto.Repositories;

import org.springframework.stereotype.Repository;

import com.example.Proyecto.entities.Escritos;

@Repository
public interface EscritoRepository extends BaseRepository<Escritos,Long> {
    
}
