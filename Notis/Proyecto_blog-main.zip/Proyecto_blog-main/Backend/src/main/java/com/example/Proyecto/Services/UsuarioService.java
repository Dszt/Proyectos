package com.example.Proyecto.Services;

import com.example.Proyecto.entities.Usuario;

public interface UsuarioService extends BaseServices<Usuario, Long> {
    
}
