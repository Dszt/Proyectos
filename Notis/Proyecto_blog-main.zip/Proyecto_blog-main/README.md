# Proyecto sobre notas
Proyecto personal, una pagina web en la que la que se creen notas y aparezcan en un mural al inicio, esto sin necesidad de crear una cuenta.
