package com.example.Proyecto.Services;

import com.example.Proyecto.entities.Escritos;


public interface EscritosServices  extends BaseServices<Escritos, Long>{
    
}
