package com.example.Proyecto.Repositories;
import org.springframework.stereotype.Repository;
import com.example.Proyecto.entities.Usuario;


@Repository
public interface UsuarioRepository extends BaseRepository<Usuario, Long>{
}
